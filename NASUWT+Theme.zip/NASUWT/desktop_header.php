<script>


$(window).load(function () {


$('.spacer').height($('.sticky').outerHeight());
  $('.spacer').addClass('spacer2');

stickyOffset = $('.sticky').offset().top;


<?php
$not_phone= <<<EOT
  $('.panel-grid').each(function() {
	var maxHeight = -1;
	panel=$(this).find('.gareth');	   


	 panel.each(function() {
		maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
		});
	//maxHeight-=$('.gareth-title').height();
	 
	 panel.each(function() {
		 $(this).css('min-height',maxHeight);
	  });
	});
});

$(window).resize(function () {





   $('.panel-grid').each(function() {

	var maxHeight = -1;
		panel=$(this).find('.gareth');	   
	 panel.each(function() {
		maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
		});
	//maxHeight-=$('.gareth-title').height();
	 
	 panel.each(function() {
		 $(this).css("min-height",maxHeight);
	  });
	});

EOT;

echo do_shortcode('[notdevice]'. $not_phone .'[/notdevice]');


?>
});


$(window).scroll(function(){
  var sticky = $('.sticky'),
      scroll = $(window).scrollTop();

  if (scroll >= stickyOffset) {
  sticky.addClass('fixed');
    $('.spacer').removeClass('spacer2');
  }
  else {
  sticky.removeClass('fixed');
    $('.spacer').addClass('spacer2');
  }
});




$(document).ready(function () {

$.fn.textWidth = function(){
  var html_org = $(this).html();
  var html_calc = '<span>' + html_org + '</span>';
  $(this).html(html_calc);
  var width = $(this).find('span:first').width();
  $(this).html(html_org);
  return width;
};


var navButtons = $('.sticky').find($('li'));

if (navButtons.length>6){
	$('.sticky').append('<ul class="second_menu menu"></ul>');
	navButtons.each(function(index) {
		if (index>5) {
		var newMe = $(this).clone();
		$('.second_menu').append(newMe);
		$(this).remove();
		}
	});
	
	console.log('true');
}

navButtons.each(function() {



if ($(this).textWidth()>$(this).width()) {
text=$(this).text();
newHTML=$(this).html();

console.log(text);
t=$(this);

while($(this).textWidth()>$(this).width()) {
			oldText=t.text();
			text = text.substr(0, text.length - 1);
			newHTML=newHTML.replace(oldText, text + "...")
			t.html(newHTML);
			console.log(text);
	}


}


});
});
</script>




<?php
$responsive= <<<EOT

@media (max-width:9000px) { #pg-2-0 .panel-grid-cell , #pg-2-1 .panel-grid-cell {
        float: none 
    }

    #pg-2-0 .panel-grid-cell , #pg-2-1 .panel-grid-cell {
        width: auto 
    }

    #pgc-2-0-0 , #pgc-2-0-1 , #pgc-2-1-0 {
        margin-bottom: 30px 
    }

    .panel-grid {
        margin-left: 0 !important;
        margin-right: 0 !important;
    }

    .panel-grid-cell {
        padding: 0 !important;
    }
}
EOT;

echo "<style>";

echo "@media (max-width:920px) { .strapline {display:none; visibility:hidden;} .title-img{content:url('http://nasuwtsuffolk.org.uk/wp-content/themes/NASUWT/images/mobile-logo.png');}}";

echo do_shortcode('[tablet]'. $responsive .'[/tablet]');
echo "</style>";
?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/desktop.css" type="text/css" media="screen" />


</head>

<div class="wrapper">
<div class="top-bar" style="background: rgba(255,255,259,1);padding:5px;" >

<?php echo do_shortcode('[notphone]'.'<div style="vertical-align:middle;display:inline-block;width:49%;margin:0px;padding:0px;">' .'[/notphone]'); ?>

<?php 
echo do_shortcode('[phone]'. "<img src='http://nasuwtsuffolk.org.uk/wp-content/themes/NASUWT/images/mobile-logo.png' height='100' style='display:block;margin-left:auto;margin-right:auto;'></img>" .'[/phone]');
echo do_shortcode('[tablet]'. "<img src='http://nasuwtsuffolk.org.uk/wp-content/themes/NASUWT/images/NASUWT.png' height='90'></img>" .'[/tablet]');
echo do_shortcode('[notdevice]'. "<img src='http://nasuwtsuffolk.org.uk/wp-content/themes/NASUWT/images/NASUWT.png' height='120' style='margin:5px;' class='title-img'></img>" .'[/notdevice]'); 
?>

<?php echo do_shortcode('[notphone]'. '</div>' .'[/notphone]'); ?>

<?php echo do_shortcode('[notphone]'. '<div style="vertical-align:middle;display:inline-block;width:50%;margin:0px;padding:0px;">'.'[/notphone]'); ?>
<?php echo do_shortcode('[tablet]'. "<img src='http://nasuwtsuffolk.org.uk/wp-content/themes/NASUWT/images/suffolk-logo.png' height='90' align='right' style='vertical-align:middle;'></img>" .'[/tablet]'); ?>

<?php echo do_shortcode('[notdevice]'. "<img src='". get_option('clubsaxx_header_setting') ."' height='120' align='right' style='vertical-align:middle;' class='strapline'></img>" .'[/notdevice]'); ?>
<?php echo do_shortcode('[notphone]'. '</div>'. '[/notphone]'); ?>

</div>
<div class="sticky">
				<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>

				<div style="clear:both;"></div></div>
</header>
<body>
<div class="spacer"></div>