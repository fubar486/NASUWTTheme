<script>


$(window).load(function () {
	$('.sticky2').hide();
	$('.sticky').addClass('fixed');
	$('.spacer').height($('.sticky').outerHeight());


	$('#menu_button').click(function () {
			
			$('.sticky2').toggle();
	
	});
	
});
</script>
</head>

<div class="wrapper">
<div class="sticky">
<div class="top-bar" style="background: rgba(255,255,259,1);padding:5px;" >
<img src='<?php echo get_option('clubsaxx_mobileheader_setting') ?>' height='100' style='display:block;margin-left:auto;margin-right:auto;'></img>
</div>
<div class="menu_button_bar">
<img src="<?php echo get_template_directory_uri()?>/images/menu.png" id="menu_button" width="50px" align="right"></img>
</div>

<div class="sticky2">
				<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>

<div style="clear:both;"></div></div></div>

<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/mobile.css" type="text/css" media="screen" />

</header>
<body>
<div class="spacer"></div>